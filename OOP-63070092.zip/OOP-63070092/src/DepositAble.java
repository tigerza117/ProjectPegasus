public interface DepositAble {
    public boolean deposit(double a);
}
