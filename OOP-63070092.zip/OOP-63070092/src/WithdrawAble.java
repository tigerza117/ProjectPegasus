public interface WithdrawAble {
    boolean withdraw(double a);
}
